package com.reflexcore.game.core

enum class GameState {
    PLAYING,
    GAME_OVER
}
